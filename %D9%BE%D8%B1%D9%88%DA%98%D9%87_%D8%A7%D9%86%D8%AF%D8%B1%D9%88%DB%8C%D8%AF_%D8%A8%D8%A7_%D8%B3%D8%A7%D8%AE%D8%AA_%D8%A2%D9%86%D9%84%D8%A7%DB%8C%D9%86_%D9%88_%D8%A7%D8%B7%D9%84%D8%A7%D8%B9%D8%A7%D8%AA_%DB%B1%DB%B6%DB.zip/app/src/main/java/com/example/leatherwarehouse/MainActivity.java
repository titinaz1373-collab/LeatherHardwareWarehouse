package com.example.leatherwarehouse;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.util.zip.GZIPInputStream;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private final int NAVY = Color.rgb(20,36,61), BLUE = Color.rgb(35,105,166);
    private final int BG = Color.rgb(243,246,250), WHITE = Color.WHITE, MUTED = Color.rgb(105,120,140);
    private LinearLayout root, header, body, bottom;
    private JSONArray models = new JSONArray();
    private JSONArray stock = new JSONArray();
    private JSONArray moves = new JSONArray();
    private String page = "models";
    private String selectedCode = null;
    private EditText modelSearch, stockSearch;
    private static final int REQ_EXPORT=101, REQ_IMPORT=102;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(NAVY);
        getWindow().setNavigationBarColor(NAVY);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        loadModels(); loadSaved();
        buildShell(); showPage("models");
    }

    private void loadModels() {
        try {
            InputStream in=new GZIPInputStream(getAssets().open("models.json.gz"));
            ByteArrayOutputStream out=new ByteArrayOutputStream();
            byte[] buf=new byte[8192]; int n;
            while((n=in.read(buf))>0) out.write(buf,0,n);
            models=new JSONArray(out.toString("UTF-8")); in.close();
        } catch(Exception e) { models=new JSONArray(); }
    }
    private void loadSaved() {
        try {
            String s=getPreferences(0).getString("stock","[]");
            stock=new JSONArray(s);
            moves=new JSONArray(getPreferences(0).getString("moves","[]"));
        } catch(Exception e) { stock=new JSONArray(); moves=new JSONArray(); }
    }
    private void save() {
        getPreferences(0).edit().putString("stock",stock.toString()).putString("moves",moves.toString()).apply();
    }

    private void buildShell() {
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        header=new LinearLayout(this); header.setOrientation(LinearLayout.VERTICAL); header.setPadding(dp(20),dp(15),dp(20),dp(15));
        header.setBackgroundColor(NAVY);
        TextView title=text("مدیریت انبار چرم و یراق",20,WHITE,true);
        TextView sub=text("مدیریت مدل‌ها، موجودی و گردش کالا",12,Color.rgb(196,210,228),false);
        header.addView(title); header.addView(sub,new LinearLayout.LayoutParams(-1,dp(24)));
        root.addView(header);
        body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.addView(body);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        bottom=new LinearLayout(this); bottom.setOrientation(LinearLayout.HORIZONTAL); bottom.setBackgroundColor(WHITE);
        bottom.setElevation(dp(10));
        root.addView(bottom,new LinearLayout.LayoutParams(-1,dp(64)));
        setContentView(root);
        refreshBottom();
    }

    private void refreshBottom() {
        bottom.removeAllViews();
        addNav("مدل‌ها","models","⌕"); addNav("موجودی","stock","▣"); addNav("گردش کالا","moves","↕");
    }
    private void addNav(String label,String key,String symbol) {
        LinearLayout item=new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER); item.setClickable(true);
        TextView ic=text(symbol,21,key.equals(page)?BLUE:MUTED,true);
        TextView tx=text(label,11,key.equals(page)?BLUE:MUTED,key.equals(page));
        item.addView(ic); item.addView(tx);
        item.setOnClickListener(v->{selectedCode=null;showPage(key);});
        bottom.addView(item,new LinearLayout.LayoutParams(0,-1,1));
    }

    private void showPage(String p) {
        page=p; selectedCode=null; body.removeAllViews(); refreshBottom();
        if(p.equals("models")) renderModels();
        else if(p.equals("stock")) renderStock();
        else renderMoves();
    }
    private void renderModels() {
        body.addView(sectionIntro("بانک اطلاعات مدل‌ها","اطلاعات ۱٬۶۹۰ مدل از ابتدا داخل برنامه ذخیره شده است."));
        LinearLayout stats=new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.addView(statCard("تعداد مدل‌ها",fa(models.length()),BLUE),new LinearLayout.LayoutParams(0,-2,1));
        stats.addView(statCard("دارای چرم",fa(countField("leather")),NAVY),new LinearLayout.LayoutParams(0,-2,1));
        stats.addView(statCard("دارای یراق",fa(countField("hardware")),NAVY),new LinearLayout.LayoutParams(0,-2,1));
        body.addView(stats);
        LinearLayout search=card(); search.addView(text("جست‌وجوی کد مدل",15,NAVY,true));
        modelSearch=new EditText(this); modelSearch.setSingleLine(true); modelSearch.setTextSize(15);
        modelSearch.setHint("مثلاً A0162"); modelSearch.setInputType( android.text.InputType.TYPE_CLASS_TEXT);
        modelSearch.setPadding(dp(14),dp(10),dp(14),dp(10)); modelSearch.setBackground(round(Color.rgb(247,249,252),Color.rgb(220,228,238),12));
        search.addView(modelSearch,new LinearLayout.LayoutParams(-1,dp(52)));
        body.addView(search);
        LinearLayout results=card(); results.addView(text("نتایج جست‌وجو",15,NAVY,true));
        LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); results.addView(list);
        body.addView(results);
        Runnable update=()->{
            list.removeAllViews();
            String q=modelSearch.getText().toString().trim().toUpperCase(Locale.ROOT);
            int shown=0;
            for(int i=0;i<models.length() && shown<80;i++) {
                JSONObject m=models.optJSONObject(i); if(m==null)continue;
                String c=m.optString("code","");
                if(c.contains(q)) { list.addView(modelRow(m)); shown++; }
            }
            if(shown==0) list.addView(empty("مدلی با این کد پیدا نشد."));
        };
        modelSearch.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){update.run();}
            public void afterTextChanged(android.text.Editable e){}
        });
        update.run();
        addBackupControls();
    }
    private int countField(String f) {
        int c=0; for(int i=0;i<models.length();i++){JSONObject o=models.optJSONObject(i);if(o!=null&&o.optJSONArray(f)!=null&&o.optJSONArray(f).length()>0)c++;}return c;
    }
    private View modelRow(JSONObject m) {
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(8),dp(12),dp(8),dp(12));
        TextView code=text(m.optString("code"),16,NAVY,true);
        row.addView(code,new LinearLayout.LayoutParams(0,-2,1));
        row.addView(chip("چرم "+fa(len(m,"leather"))));
        row.addView(chip("یراق "+fa(len(m,"hardware"))));
        TextView open=text("›",27,BLUE,true); open.setPadding(dp(10),0,dp(10),0); row.addView(open);
        row.setOnClickListener(v->showDetail(m.optString("code")));
        View line=new View(this); line.setBackgroundColor(Color.rgb(235,239,244));
        LinearLayout wrap=new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL); wrap.addView(row); wrap.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        return wrap;
    }
    private int len(JSONObject o,String key){JSONArray a=o.optJSONArray(key);return a==null?0:a.length();}

    private void showDetail(String code) {
        page="detail"; selectedCode=code; body.removeAllViews(); refreshBottom();
        TextView back=button("بازگشت به فهرست",false); back.setOnClickListener(v->showPage("models")); body.addView(back);
        JSONObject m=findModel(code);
        body.addView(sectionIntro("مدل "+code,"ریز مصرف چرم و یراق"));
        body.addView(text("مصرف چرم",17,NAVY,true));
        JSONArray leather=m==null?new JSONArray():m.optJSONArray("leather");
        if(leather==null||leather.length()==0) body.addView(empty("برای این مدل مصرف چرمی ثبت نشده است."));
        else for(int i=0;i<leather.length();i++) {
            JSONObject x=leather.optJSONObject(i); LinearLayout c=card();
            addPair(c,"نوع چرم",x.optString("type")); addPair(c,"سورت",x.optString("sort"));
            addPair(c,"ضخامت",x.optString("thickness")); addPair(c,"مصرف استاندارد",x.optString("usage"));
            if(!x.optString("decoration").isEmpty())addPair(c,"تزیین",x.optString("decoration"));
            body.addView(c);
        }
        body.addView(text("مصرف یراق",17,NAVY,true));
        JSONArray hardware=m==null?new JSONArray():m.optJSONArray("hardware");
        if(hardware==null||hardware.length()==0) body.addView(empty("برای این مدل یراقی ثبت نشده است."));
        else for(int i=0;i<hardware.length();i++) {
            JSONObject x=hardware.optJSONObject(i); LinearLayout c=card();
            addPair(c,"عنوان ملزومات",x.optString("item")); addPair(c,"مشخصات",x.optString("specification"));
            addPair(c,"مقدار",x.optString("quantity")+" "+x.optString("unit"));
            body.addView(c);
        }
    }
    private JSONObject findModel(String code) {
        for(int i=0;i<models.length();i++){JSONObject m=models.optJSONObject(i);if(m!=null&&code.equals(m.optString("code")))return m;}return null;
    }

    private void renderStock() {
        body.addView(sectionIntro("موجودی انبار","ثبت کالا، اصلاح مقدار و مشاهده هشدار کمبود"));
        TextView add=button("＋ افزودن / اصلاح قلم موجودی",true);
        add.setOnClickListener(v->stockDialog(null)); body.addView(add);
        LinearLayout search=card(); stockSearch=new EditText(this); stockSearch.setSingleLine(true); stockSearch.setHint("جست‌وجوی نام کالا");
        stockSearch.setTextSize(14); search.addView(stockSearch,new LinearLayout.LayoutParams(-1,dp(48))); body.addView(search);
        LinearLayout list=card(); list.addView(text("فهرست موجودی",16,NAVY,true)); body.addView(list);
        Runnable update=()->{
            while(list.getChildCount()>1)list.removeViewAt(1);
            String q=stockSearch.getText().toString().trim();
            int n=0;
            for(int i=0;i<stock.length();i++){
                JSONObject x=stock.optJSONObject(i); if(x==null||!x.optString("name").contains(q))continue;
                LinearLayout item=card(); addPair(item,x.optString("name"),faNum(x.optString("qty"))+" "+x.optString("unit"));
                String status=x.optDouble("qty")<=x.optDouble("min")?"نیازمند تأمین":"وضعیت عادی";
                TextView st=text(status+"  ·  حد هشدار: "+faNum(x.optString("min")),12,x.optDouble("qty")<=x.optDouble("min")?Color.rgb(185,105,20):MUTED,false);
                item.addView(st);
                LinearLayout actions=new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL);
                TextView edit=button("ویرایش",false); edit.setOnClickListener(v->stockDialog(x));
                TextView move=button("ثبت ورود / خروج",true); move.setOnClickListener(v->moveDialog(x));
                actions.addView(edit,new LinearLayout.LayoutParams(0,dp(44),1)); actions.addView(move,new LinearLayout.LayoutParams(0,dp(44),1)); item.addView(actions);
                list.addView(item); n++;
            }
            if(n==0)list.addView(empty("هنوز قلمی ثبت نشده است."));
        };
        stockSearch.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){update.run();}public void afterTextChanged(android.text.Editable e){}});
        update.run();
        addBackupControls();
    }
    private void stockDialog(JSONObject existing) {
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(8),dp(4),dp(8),dp(4));
        EditText name=field("نام کالا",existing==null?"":existing.optString("name"));
        EditText unit=field("واحد (عدد، متر، کیلوگرم...)",existing==null?"عدد":existing.optString("unit"));
        EditText qty=field("موجودی فعلی",existing==null?"0":existing.optString("qty"));
        EditText min=field("حد هشدار",existing==null?"0":existing.optString("min"));
        form.addView(name);form.addView(unit);form.addView(qty);form.addView(min);
        new AlertDialog.Builder(this).setTitle(existing==null?"افزودن قلم موجودی":"اصلاح قلم موجودی").setView(form)
            .setNegativeButton("انصراف",null).setPositiveButton("ذخیره",(d,w)->{
                try{
                    JSONObject x=existing==null?new JSONObject():existing;
                    x.put("name",name.getText().toString().trim());x.put("unit",unit.getText().toString().trim());
                    x.put("qty",Double.parseDouble(qty.getText().toString()));x.put("min",Double.parseDouble(min.getText().toString()));
                    if(existing==null){x.put("id",System.currentTimeMillis());stock.put(x);}
                    save();showPage("stock");
                }catch(Exception e){toast("مقادیر عددی را بررسی کن.");}
            }).show();
    }
    private void moveDialog(JSONObject item) {
        LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);form.setPadding(dp(8),dp(4),dp(8),dp(4));
        Spinner type=new Spinner(this);ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"ورود","خروج"});type.setAdapter(ad);
        EditText qty=field("مقدار", "1");EditText note=field("شرح / شماره سند","");form.addView(type);form.addView(qty);form.addView(note);
        new AlertDialog.Builder(this).setTitle("گردش کالا: "+item.optString("name")).setView(form).setNegativeButton("انصراف",null).setPositiveButton("ثبت",(d,w)->{
            try{
                double amount=Double.parseDouble(qty.getText().toString());double current=item.optDouble("qty");
                boolean incoming=type.getSelectedItemPosition()==0;
                if(amount<=0)throw new Exception();
                if(!incoming&&amount>current){toast("موجودی کافی نیست.");return;}
                item.put("qty",incoming?current+amount:current-amount);
                JSONObject mv=new JSONObject();mv.put("date",new SimpleDateFormat("yyyy/MM/dd  HH:mm",Locale.getDefault()).format(new Date()));
                mv.put("name",item.optString("name"));mv.put("type",incoming?"ورود":"خروج");mv.put("qty",amount);mv.put("note",note.getText().toString());
                moves.put(0,mv);save();showPage("stock");toast("گردش کالا ثبت شد.");
            }catch(Exception e){toast("مقدار واردشده معتبر نیست.");}
        }).show();
    }
    private void renderMoves() {
        body.addView(sectionIntro("گردش کالا","سوابق ورود و خروج ثبت‌شده در این گوشی"));
        LinearLayout list=card();list.addView(text("آخرین گردش‌ها",16,NAVY,true));body.addView(list);
        if(moves.length()==0)list.addView(empty("هنوز گردش کالایی ثبت نشده است."));
        for(int i=moves.length()-1;i>=0;i--){
            JSONObject x=moves.optJSONObject(i);if(x==null)continue;
            LinearLayout c=card();addPair(c,x.optString("name"),x.optString("type")+"  "+faNum(x.optString("qty")));
            c.addView(text(x.optString("date")+"   "+x.optString("note"),11,MUTED,false));list.addView(c);
        }
        addBackupControls();
    }
    private void addBackupControls() {
        LinearLayout c=card();c.addView(text("پشتیبان اطلاعات",15,NAVY,true));
        TextView ex=button("خروجی گرفتن از اطلاعات انبار",false);ex.setOnClickListener(v->exportBackup());
        TextView im=button("بازیابی فایل پشتیبان",false);im.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,REQ_IMPORT);});
        c.addView(ex);c.addView(im);body.addView(c);
    }
    private void exportBackup() {
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"warehouse-backup.json");startActivityForResult(i,REQ_EXPORT);
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null)return;
        try{
            if(request==REQ_EXPORT){
                JSONObject b=new JSONObject();b.put("stock",stock);b.put("moves",moves);
                OutputStream out=getContentResolver().openOutputStream(data.getData());out.write(b.toString(2).getBytes("UTF-8"));out.close();toast("فایل پشتیبان ذخیره شد.");
            }else if(request==REQ_IMPORT){
                InputStream in=getContentResolver().openInputStream(data.getData());ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))>0)out.write(buf,0,n);in.close();
                JSONObject b=new JSONObject(out.toString("UTF-8"));stock=b.optJSONArray("stock");moves=b.optJSONArray("moves");if(stock==null)stock=new JSONArray();if(moves==null)moves=new JSONArray();save();showPage(page.equals("moves")?"moves":"stock");toast("بازیابی اطلاعات انجام شد.");
            }
        }catch(Exception e){toast("عملیات پشتیبان انجام نشد.");}
    }

    private LinearLayout sectionIntro(String title,String subtitle) {
        LinearLayout c=card();c.addView(text(title,20,NAVY,true));c.addView(text(subtitle,12,MUTED,false));return c;
    }
    private LinearLayout statCard(String label,String value,int color) {
        LinearLayout c=card();c.addView(text(label,11,MUTED,false));c.addView(text(value,19,color,true));return c;
    }
    private LinearLayout card() {
        LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(15),dp(13),dp(15),dp(13));
        c.setBackground(round(WHITE,Color.rgb(231,236,243),16));c.setElevation(dp(2));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(dp(12),dp(7),dp(12),dp(7));c.setLayoutParams(lp);return c;
    }
    private TextView text(String s,int size,int color,boolean bold) {
        TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);t.setPadding(0,dp(3),0,dp(3));return t;
    }
    private TextView chip(String s) {
        TextView t=text(s,10,BLUE,true);t.setPadding(dp(8),dp(4),dp(8),dp(4));t.setBackground(round(Color.rgb(235,244,252),Color.TRANSPARENT,18));return t;
    }
    private TextView button(String s,boolean primary) {
        TextView t=text(s,13,primary?WHITE:BLUE,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(12),dp(9),dp(12),dp(9));
        t.setBackground(round(primary?BLUE:Color.rgb(235,242,249),Color.TRANSPARENT,12));t.setClickable(true);return t;
    }
    private TextView empty(String s) {TextView t=text(s,13,MUTED,false);t.setGravity(Gravity.CENTER);t.setPadding(dp(12),dp(20),dp(12),dp(20));return t;}
    private void addPair(LinearLayout parent,String label,String value) {
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);
        TextView l=text(label,12,MUTED,false),v=text(value,13,NAVY,true);
        row.addView(l,new LinearLayout.LayoutParams(0,-2,1));row.addView(v,new LinearLayout.LayoutParams(0,-2,2));parent.addView(row);
    }
    private EditText field(String hint,String value) {
        EditText e=new EditText(this);e.setSingleLine(true);e.setTextSize(14);e.setHint(hint);e.setText(value);e.setPadding(dp(10),dp(6),dp(10),dp(6));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));lp.setMargins(0,dp(3),0,dp(3));e.setLayoutParams(lp);return e;
    }
    private GradientDrawable round(int color,int stroke,int radius) {
        GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));if(stroke!=Color.TRANSPARENT)d.setStroke(dp(1),stroke);return d;
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private String fa(int n){return faNum(String.valueOf(n));}
    private String faNum(String s){return s.replace('0','۰').replace('1','۱').replace('2','۲').replace('3','۳').replace('4','۴').replace('5','۵').replace('6','۶').replace('7','۷').replace('8','۸').replace('9','۹');}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
